# aapTask1
Design and implement a dashboard for the top influencers  Try to create a web page to display influencers' data by fetching it using a GET request. The user should be able to see the data effectively and easily.

Source for data: http://demo4469839.mockable.io/influencers
